#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <assert.h>

#define DEFAULT_HTTP_PORT 80

typedef struct url_s
{
  unsigned short usPort;   // in host byte order
  char          *szServer; // allocated by parse_url(), must be freed by the caller
  char          *szFile;   // allocated by parse_url(), must be freed by the caller
} url_t;


url_t parse_url(const char *szURL)
{
  url_t url;
  memset(&url, 0, sizeof(url));

	unsigned int urllen = strlen(szURL) + 1;
	url.szServer = (char*) malloc(urllen * sizeof(char));
	assert(NULL != url.szServer);
	url.szFile = (char*) malloc(urllen * sizeof(char));
	assert(NULL != url.szFile);

  char server[urllen];
  int result = sscanf(szURL, "http://%[^/]/%s", server, url.szFile);
  if (EOF == result)
  {
    fprintf(stderr, "Failed to parse URL: %s\n", strerror(errno));
    exit(1);
  }
  else if (1 == result)
  {
    url.szFile[0] = '\0';
  }
  else if (result < 1)
  {
    fprintf(stderr, "Error: %s is not a valid HTTP request\n", szURL);
    exit(1);
  }

  result = sscanf(server, "%[^:]:%hu", url.szServer, &url.usPort);
  if (EOF == result)
  {
    fprintf(stderr, "Failed to parse URL: %s\n", strerror(errno));
    exit(1);
  }
  else if (1 == result)
  {
    url.usPort = DEFAULT_HTTP_PORT;
  }
  else if (result < 1)
  {
    fprintf(stderr, "Error: %s is not a valid HTTP request\n", szURL);
    exit(1);
  }

	assert(NULL != url.szServer);
	assert(NULL != url.szFile);
	assert(url.usPort > 0);
  return url;
}


int main(int argc, char **argv)
{
  if (argc < 2)
  {
    fprintf(stderr,
            "Usage: http_client URL\n");
    exit(1);
  }

  // Parse the URL
  url_t url = parse_url(argv[1]);
  fprintf(stderr, "Server: %s:%hu\nFile: /%s\n",
          url.szServer, url.usPort, url.szFile);


  return 0;
}
